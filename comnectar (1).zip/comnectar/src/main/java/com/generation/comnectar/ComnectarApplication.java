package com.generation.comnectar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComnectarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComnectarApplication.class, args);
	}

}
